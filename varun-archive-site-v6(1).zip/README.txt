Varun Archive v6

You can now:
- Edit ANY chapter (CORE included) via ADMIN -> MANAGE CHAPTERS -> Edit
  * Editing sets an override body for that chapter, giving you full control.
- Delete ANY chapter (CORE included) via ADMIN -> MANAGE CHAPTERS -> Delete
- Edit & Delete ANY revision via ADMIN -> MANAGE REVISIONS

GitHub update (ELI5):
1) Extract ZIP
2) Repo -> Add file -> Upload files
3) Upload index.html (replace old)
4) Commit changes
5) Wait ~60s then hard refresh (Ctrl+Shift+R)
